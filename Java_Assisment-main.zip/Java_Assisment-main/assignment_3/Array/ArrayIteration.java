public class ArrayIteration {
    public static void main(String[] args) {
        int[] array = { 5, 10, 15, 20, 25 };
        int index = 0;

        while (index < array.length) {
            System.out.println(array[index]);
            index++;
        }
    }
}
