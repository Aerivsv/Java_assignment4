public class ToUpperCaseExample {
    public static void main(String[] args) {
        String str = "Hello, World!";
        String uppercaseStr = str.toUpperCase();
        System.out.println("Original string: " + str);
        System.out.println("Uppercase string: " + uppercaseStr);
    }
}
