public class EqualsExample {

    public static void main(String[] args) {
        String text = "Hello, World!";
        String otherText = "Hello, World!";

        boolean isEqual = text.equals(otherText);
        System.out.println("Strings are equal: " + isEqual);
    }
}
