public class SubstringExample {

    public static void main(String[] args) {
        String text = "Hello, World!";
        int beginIndex = 7;

        String substring = text.substring(beginIndex);
        System.out.println("Substring from index " + beginIndex + ": " + substring);
    }
}
