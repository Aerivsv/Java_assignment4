public class CharAtExample {

    public static void main(String[] args) {
        String text = "Hello, World!";
        int index = 7;

        char character = text.charAt(index);
        System.out.println("Character at index " + index + ": " + character);
    }
}
