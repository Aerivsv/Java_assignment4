public class StringClassObject {
    public static void main(String[] args) {
        String name = new String("ChatGPT");
        System.out.println(name);
    }
}
