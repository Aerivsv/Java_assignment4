public class IndexOfExample {
    public static void main(String[] args) {
        String str = "Hello, World!";
        char ch = 'o';
        int index = str.indexOf(ch);
        System.out.println("Index of '" + ch + "' in the string: " + index);
    }
}
