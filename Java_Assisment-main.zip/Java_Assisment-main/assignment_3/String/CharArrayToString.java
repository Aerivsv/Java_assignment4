public class CharArrayToString {
    public static void main(String[] args) {
        char[] nameChars = {'C', 'h', 'a', 't', 'G', 'P', 'T'};
        String name = new String(nameChars);
        System.out.println(name);
    }
}
