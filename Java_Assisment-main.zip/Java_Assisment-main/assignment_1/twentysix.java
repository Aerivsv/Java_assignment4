public class twentysix {
    
    public static void main(String[] args) {
        
        int num = 10;
        int i = 1;
        int res = 1;

        for (i=1 ; i<=num ; i++){
            res = res * i;
        }
        System.out.println("Factorial of " + 5 + " is " + res);
    }
}
