public class thirteen {

    public static void main(String[] args) {
        
        int num = 35;

        if(num%7==0){
            System.out.println(num + " is divisible by 7.");
        }
        else{
            System.out.println(num + " cannot divisible by 7.");
        }
    }
}
