public class eleven{

    public static void main(String[] args) {
        byte defaultbyte = 0;
        short defaultshort = 0;
        int defaultint = 0;     
        long defaultlong = 0L;
        float defaultfloat = 0.0f;
        double defaultdouble = 0.0d;
        char defaultchar = '\u0000';
        boolean defaultboolean = false;

        System.out.println("e default value of byte = " + defaultbyte);
        System.out.println("e default value of short = " + defaultshort);
        System.out.println("e default value of int = " + defaultint);
        System.out.println("e default value of long = " + defaultlong);
        System.out.println("e default value of float = " + defaultfloat);
        System.out.println("e default value of double = " + defaultdouble);
        System.out.println("e default value of char = " + defaultchar);
        System.out.println("e default value of boolean = " + defaultboolean);
        }
}