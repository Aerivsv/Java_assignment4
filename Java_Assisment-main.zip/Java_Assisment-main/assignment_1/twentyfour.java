public class twentyfour {
    
    public static void main(String[] args) {
        
        int n = 10;
        int sum = 0;

        for (int i=1 ; i<=n ; i++){
            sum += i;
        }
        System.out.println("The Sum of N netural numbers is : " + sum);
    }
}
