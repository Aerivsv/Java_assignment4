public class three {
    
    public static void main(String[] args) {
        int P = 1000, R = 5, T = 5;
        float si = (P * R * T) / 100;

        System.out.println("Simple Interest = " + si);
    }
}
