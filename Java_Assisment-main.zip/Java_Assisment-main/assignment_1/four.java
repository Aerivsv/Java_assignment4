public class four {
    
    public static void main(String[] args) {
        int L = 4;

        System.out.println("Area of a square = " + L*L);
    }
}
