public class twelve {
    
    public static void main(String[] args) {
        
        int num = 30;

        String op = (num%2 == 0) ? " is Even." : " is Odd.";

        System.out.println(num + op);

        //--------------------------Using If - Else---------------------

        // if(num%2==0){
        //     System.out.println(num + " is Even.");
        // }
        // else{
        //     System.out.println(num + " is Odd.");
        // }
    }
}
