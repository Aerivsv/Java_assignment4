public class fourteen {
    
    public static void main(String[] args) {
        
        int num = 55;

        if (num%2==0){
            System.out.println(num + " is Even.");
        }
        else{
            System.out.println(num + " is Odd.");
        }
    }
}
